﻿using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

public class EmailService
{
    // Gmail SMTP settings
    private readonly string smtpServer = "smtp.gmail.com";
    private readonly int port = 587; // TLS port
    private readonly string email = "carrersolutionproject@gmail.com"; // Replace with your Gmail address
    private readonly string password = "Aditya@1234"; // Replace with your Gmail password or App Password

    public async Task SendEmailAsync(string toEmail, string subject, string body)
    {
        // Create a new SmtpClient instance
        using (var client = new SmtpClient(smtpServer, port))
        {
            // Set the credentials using your Gmail account
            client.Credentials = new NetworkCredential(email, password);
            client.EnableSsl = true; // Enable SSL for secure connection

            // Create a MailMessage
            var mailMessage = new MailMessage
            {
                From = new MailAddress(email), // Sender's email address
                Subject = subject,              // Subject of the email
                Body = body,                    // Body of the email
                IsBodyHtml = true               // Specify that the body is in HTML format
            };
            mailMessage.To.Add(toEmail); // Add the recipient's email address

            // Send the email asynchronously
            await client.SendMailAsync(mailMessage);
        }
    }
}