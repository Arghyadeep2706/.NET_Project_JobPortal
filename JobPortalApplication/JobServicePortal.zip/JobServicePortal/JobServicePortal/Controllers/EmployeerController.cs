﻿using DNTCaptcha.Core.Providers;
using DNTCaptcha.Core;
using JobServicePortal.Models;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;
using Microsoft.AspNetCore.Builder;

namespace JobServicePortal.Controllers
{
    public class EmployeerController : Controller
    {
        private readonly jobPortalNewContext _context;
        private readonly IDNTCaptchaValidatorService _validatorService;

        public EmployeerController(jobPortalNewContext context, IDNTCaptchaValidatorService validatorService)
        {
            _context = context;
            _validatorService = validatorService;
        }

        private byte[] HashPassword(string password)
        {
            return Encoding.UTF8.GetBytes(password);
            //using var sha256 = SHA256.Create();
            //return sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
        }

        [HttpGet]
        public IActionResult CRegistration()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateDNTCaptcha(ErrorMessage = "Please enter a valid Captcha.",
   CaptchaGeneratorLanguage = Language.English,
   CaptchaGeneratorDisplayMode = DisplayMode.ShowDigits)]
        public IActionResult CRegistration(CompanyRegistration registration)
        {
            // Validate Captcha
            if (!_validatorService.HasRequestValidCaptchaEntry(Language.English, DisplayMode.ShowDigits))
            {
                ModelState.AddModelError(DNTCaptchaTagHelper.CaptchaInputName, "Please enter a valid Captcha.");
            }

            // Check for existing company by email or name
            if (_context.CompanyRegistrations.Any(c => c.Email == registration.Email || c.CompanyName == registration.CompanyName))
            {
                ModelState.AddModelError(string.Empty, "A company with this email or name already exists.");
            }

            if (ModelState.IsValid)
            {
                // Hash the password before saving
                registration.Password = HashPassword(registration.NormPassword);

                try
                {
                    // Add the new registration to the context
                    _context.CompanyRegistrations.Add(registration);

                    // Save changes to the database
                    if (_context.SaveChanges() > 0)
                    {
                        ViewData["MessageAppRegistration"] = "User registered successfully.";
                        return RedirectToAction("CLogin"); // Redirect to the login action
                    }
                    else
                    {
                        ViewData["MessageAppRegistration"] = "Registration failed. Please try again.";
                    }
                }
                catch (DbUpdateException ex)
                {
                    // Log the exception (consider using a logging framework)
                    ViewData["MessageAppRegistration"] = "An error occurred while registering the user: " + ex.Message;
                }
            }

            // Return view with current model to show validation messages
            return View(registration);
        }

        [HttpGet]
        public IActionResult CLogin()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateDNTCaptcha(ErrorMessage = "Please Enter Valid Captcha",
            CaptchaGeneratorLanguage = Language.English,
            CaptchaGeneratorDisplayMode = DisplayMode.ShowDigits)]

        public IActionResult CLogin(string email, string password)
        {
            // Encode the password to byte array
            byte[] p = Encoding.UTF8.GetBytes(password);

            if (ModelState.IsValid)
            {
                // Check if the CAPTCHA is valid
                if (!_validatorService.HasRequestValidCaptchaEntry(Language.English, DisplayMode.ShowDigits))
                {
                    this.ModelState.AddModelError(DNTCaptchaTagHelper.CaptchaInputName, "Please Enter Valid Captcha.");
                     // Return to the view to show errors
                }

                // Check for matching records for email and password
                var res = (from t in _context.CompanyRegistrations
                           where t.Email == email && t.Password == p
                           select t).Count();


                if (res > 0)
                {
                    HttpContext.Session.SetString("uid", email);

                    // Create claims for authentication
                    var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, email)
            };

                    var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    var authProperties = new AuthenticationProperties
                    {
                        IsPersistent = true
                    };

                    // Redirect to the home page after successful login
                    return RedirectToAction("Index");
                }
                else
                {
                    // Invalid login attempt
                    TempData["MessageCompanyLogin"] = "Invalid User..!!!!";
                }
            }

            // Return the view if model state is not valid or login failed
            return View();
        }


        [HttpGet]
        public IActionResult Logout()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Logout(string a)
        {
            HttpContext.Session.Clear(); // Clear all session data
            return RedirectToAction("App_Login", "Login"); // Redirect to Login page


        }

        [HttpGet]
        public IActionResult ResetPasswords()
        {
            return View();
        }

        [HttpPost]

        public IActionResult ResetPasswords(string t, string newPassword, string conPassword, string oldPassword, CompanyRegistration u)
        {


            //byte[] p = Encoding.UTF8.GetBytes(oldPassword);

            var res = (from r in _context.CompanyRegistrations
                       where r.Email == t
                       select r).FirstOrDefault();

            if (res != null)
            {
                if (newPassword == conPassword)
                {
                    res.Password = Encoding.UTF8.GetBytes(newPassword);

                    int i = _context.SaveChanges();

                    if (i > 0)
                    {
                        ViewData["x"] = "Reset successfully";
                    }
                    else
                    {
                        ViewData["x"] = "Failed to reset password";
                    }
                }
                else
                {
                    ViewData["x"] = "New Password and Confirm Password Mismatch";
                }

            }
            else
            {
                ViewData["x"] = "User not found";
            }

            return View();
        }


      


        [HttpGet]
        public IActionResult Index()
        {
            //// Assume you have a way to get the logged-in user's company ID
            //int loggedInCompanyId = GetLoggedInCompanyId(); // Replace with your actual method to get the logged-in company ID

            //var jobPosts = _context.JobPosts
            //    .Where(j => j.CompanyId == loggedInCompanyId) // Filter by the logged-in company's ID
            //    .ToList();

            return View();

        }
        [HttpPost]
        public IActionResult Index(JobPost j)
        {
            var res = from t in _context.JobPosts
                      select t;


            return View(res);
        }

        //Method to get the logged-in company's ID (you'll need to implement this)
        private int GetLoggedInCompanyId()
        {
            //For example, you might retrieve it from the user's session or claims
             //return HttpContext.Session.GetInt32("CompanyId") ?? 0;
            return 2; // Replace with actual implementation
        }


        [HttpGet]
        public IActionResult SearchCandidates()
        {
            PopulateSkills();
            return View(new List<JobApplicant>()); // Return an empty list initially
        }

        [HttpPost]
        public IActionResult SearchCandidates(string primarySkills)
        {
            PopulateSkills(); // Repopulate skills for the dropdowns

            // Fetch candidates based on the selected primary skills
            var candidates = _context.Skills
                .Where(s => s.PrimarySkill == primarySkills)
                .GroupBy(s => s.CandidateId) // Group by candidate ID
                .Select(g => g.FirstOrDefault().Candidate) // Select the first candidate from each group
                .ToList();

            // Handle the case where candidates might be null
            if (candidates == null || !candidates.Any())
            {
                ViewBag.Message = "No candidates found with the specified primary skill.";
                return View(new List<JobApplicant>()); // Return an empty list
            }

            return View("SearchCandidates", candidates);
        }

        private void PopulateSkills()
        {
            var primarySkills = _context.Skills
                .Select(s => s.PrimarySkill)
                .Distinct()
                .ToList();

            ViewBag.PrimarySkills = primarySkills;
        }




        [HttpGet]
        public IActionResult PostJob()
        {
            return View();
        }
        [HttpPost]
        public IActionResult PostJob(JobPost r)
        {
            if (ModelState.IsValid)
            {
                _context.JobPosts.Add(r);

                // Attempt to save changes to the database
                int i = _context.SaveChanges();
                if (i > 0)
                {
                    // Redirect to the Index action to show all job posts
                    return RedirectToAction("Index");
                }
                else
                {
                    ViewData["Message"] = "Failed to add job.";
                }
            }

            // Return the model to retain form data in case of validation errors
            return View(r);
        }






        [HttpGet]
        public IActionResult EditJob(int id)
        {
            var jobPost = _context.JobPosts.Find(id);
            if (jobPost == null)
            {
                return NotFound();
            }

            ViewBag.Companies = _context.Companies.ToList(); // Populate companies for dropdown
            return View(jobPost);
        }

        [HttpPost]
        public IActionResult EditJob(JobPost jobPost)
        {
            if (ModelState.IsValid)
            {
                // Check if the company exists
                if (!_context.Companies.Any(c => c.CompanyId == jobPost.CompanyId))
                {
                    ModelState.AddModelError("CompanyId", "The selected company does not exist.");
                    ViewBag.Companies = _context.Companies.ToList(); // Repopulate companies
                    return View(jobPost);
                }

                _context.JobPosts.Update(jobPost);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Companies = _context.Companies.ToList(); // Repopulate companies on error
            return View(jobPost);
        }



        [HttpGet]
        public IActionResult ViewJobDescription(int id)
        {
            var jobPost = _context.JobPosts.Find(id);
            if (jobPost == null)
            {
                return NotFound();
            }
            return View(jobPost);
        }



        [HttpGet]
        public IActionResult DeleteJob(int id)
        {
            var jobPost = _context.JobPosts.Find(id);
            if (jobPost == null)
            {
                return NotFound();
            }
            return View(jobPost);
        }

        [HttpPost, ActionName("DeleteJob")]
        public IActionResult DeleteConfirmed(int id)
        {
            var jobPost = _context.JobPosts.Find(id);
            if (jobPost != null)
            {
                _context.JobPosts.Remove(jobPost);
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> ViewJobApplications(int jobId)
        {
            var applications = await _context.JobApplications
                .Include(a => a.Applicant) // Ensure applicant details are included
            .Where(a => a.JobId == jobId)
                .Select(a => new JobApplication
                {
                    //ApplicantName = $"{a.Applicant.FirstName} {a.Applicant.LastName}",
                    // Email = a.Applicant.EmailId,
                    AppliedDate = a.AppliedDate,
                    Resume = a.Resume,
                })
                .ToListAsync();

            if (!applications.Any())
            {
                return NotFound("No applications found for this job posting.");
            }

            return View(applications);
        }

        //[HttpGet]
        //public async Task<IActionResult> DownloadResume(int applicationId)
        //{
        //    var application = await _context.JobApplications
        //        .Include(a => a.Applicant) // Include applicant details
        //        .FirstOrDefaultAsync(a => a.ApplicationId == applicationId);

        //    if (application == null || string.IsNullOrEmpty(application.Resume) || !System.IO.File.Exists(application.Resume))
        //    {
        //        return NotFound("Resume not found.");
        //    }

        //    var contentType = "application/pdf"; // Adjust according to your file type
        //    var fileName = Path.GetFileName(application.Resume);

        //    // Return the file
        //    return File(System.IO.File.ReadAllBytes(application.Resume), contentType, fileName);
        //}

        [HttpGet]
        // Ensure the user is logged in
        public async Task<IActionResult> ViewProfile()
        {
            int loggedInCompanyId = GetLoggedInCompanyId(); // Get the current company ID
            var company = await _context.Companies.FindAsync(loggedInCompanyId);

            if (company == null)
            {
                return NotFound("Company not found.");
            }

            return View(company);
        }


    }
}
    


    





