﻿using JobServicePortal.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Org.BouncyCastle.Pqc.Crypto.Lms;
using System.IO;
using System.Threading.Tasks;

namespace JobServicePortal.Controllers
{
    public class JobApplicationController : Controller
    {
        jobPortalNewContext dc = new jobPortalNewContext();
        private readonly EmailService _emailService;

        public JobApplicationController(jobPortalNewContext context)
        {
            
            _emailService = new EmailService();
        }

        // GET: JobApplication/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: JobApplication/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(JobApplicant applicant, IFormFile ResumePath)
        {
            var filePath = Path.Combine("wwwroot/resumes", ResumePath.FileName);

            //using (var stream = new FileStream(filePath, FileMode.Create))
            //{
            //    await ResumePath.CopyToAsync(stream);
            //}

            using (var memoryStream = new MemoryStream())
            {
                // Copy the file to the memory stream
                await ResumePath.CopyToAsync(memoryStream);
                applicant.Resumee = memoryStream.ToArray(); // Store the file as a byte array
            }

            //    if (ModelState.IsValid)
            {
                // Check if the resume file is provided
                if (ResumePath != null && ResumePath.Length > 0)
                {
                    var fileExt = Path.GetExtension(ResumePath.FileName).ToUpperInvariant();

                    // Validate that the file is a PDF
                    if (fileExt == ".PDF")
                    {
                        try
                        {
                            //using (var memoryStream = new MemoryStream())
                            //{
                            //    // Copy the file to the memory stream
                            //    await ResumePath.CopyToAsync(memoryStream);
                            //    applicant.Resumee = memoryStream.ToArray(); // Store the file as a byte array
                            //}
                        }
                        catch (Exception ex)
                        {
                            ModelState.AddModelError(string.Empty, $"Error processing the file: {ex.Message}");
                            return View(applicant);
                        }
                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Invalid file format. Only PDF files are allowed.");
                        return View(applicant);
                    }
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Please upload a resume.");
                    return View(applicant);
                }

                // Add the applicant to the database
                dc.JobApplicants.Add(applicant);

                try
                {
                    await dc.SaveChangesAsync();
                    TempData["Message"] = "Job Applicant created successfully!";
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateException ex)
                {
                    ModelState.AddModelError(string.Empty, $"Error saving applicant: {ex.Message}");
                }
            }
            //else
            //{
            //    ModelState.AddModelError(string.Empty, "Please correct the errors in the form.");
            //}

            // Return the view with the model containing validation errors
            return View(applicant);
        }



        // GET: JobApplication/Index
        public IActionResult Index()
        {

            var applicants = (from t in dc.JobApplicants
                              select t).ToList();


            int i = applicants.Count();
         //   var applicants = dc.JobApplicants.ToList();
            return View(applicants); // Return the list of applicants to the view
        }

        // GET: JobApplication/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var applicant = await dc.JobApplicants.FindAsync(id);
            if (applicant == null)
            {
                return NotFound();
            }
            return View(applicant); // Return the applicant to confirm deletion
        }

        // GET: JobApplication/Details/5
        

        public IActionResult Details(int id)
        {
            var applicant = dc.JobApplicants.Find(id);
            if (applicant == null) return NotFound();
            return View(applicant);
        }

    }
}



