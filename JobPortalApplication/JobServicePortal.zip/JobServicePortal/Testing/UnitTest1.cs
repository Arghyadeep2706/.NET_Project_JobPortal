using JobServicePortal.Models;
using JobServicePortal.Controllers;

using Microsoft.AspNetCore.Mvc;

namespace Testing
{
    //public class UnitTest1
    //{
    //    LoginController _controller;
    //    RegistrationController _controller1;
    //    ApplicantRegistration ar = new ApplicantRegistration();


    //    [OneTimeSetUp]
        
    //    public void test()
    //    {
    //        _controller = new LoginController();
    //        _controller1 = new RegistrationController();

    //    }

    //    [OneTimeTearDown]

    //    public void test1()
    //    {
    //        _controller.Dispose();
    //        _controller1.Dispose();
    //    }


    //    [Test]
    //    public void Login_ValidCredentials_RedirectsToAbout()
    //    {
    //        string username = "kriti";
    //        string password = "adi";
            

    //        var result = _controller.App_Login(username, password) as RedirectToActionResult;

    //        Assert.IsNotNull(result);
    //        Assert.AreEqual("About", result.ActionName);

    //    }

    //    [Test]
    //    public void Login_InvalidCredentials_RedirectsToError()
    //    {
    //        string username = "user";
    //        string password = "wrongpassword";

    //        var result = _controller.App_Login(username, password) as ViewResult;

    //        Assert.NotNull(result);
    //        Assert.AreEqual("Invalid User..!!!!", result.ViewData["MessageAppLogin"]);
    //    }


        //[Test]
        //public void Register_ValidCredentials_RedirectsToLogin()
        //{
        //    // Arrange
           
            
        //    int user_id = 567;
        //    string username = "kriti";
        //    string password = "adi";
        //    string email = "kriti@gmail.com";
        //    string first_name = "kriti";
        //    string second_name = "sanon";
        //    int phone = 123444556;
            


        //    // Act
        //    var result = _controller1.App_Registration(user_id, username, password, email, first_name, second_name, phone) as RedirectToActionResult;
        //    // Assert
        //    Assert.NotNull(result);
        //    Assert.AreEqual("Login",result.ActionName);
        //}


    }

    
}